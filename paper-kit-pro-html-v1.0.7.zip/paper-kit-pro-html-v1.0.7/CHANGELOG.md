## V1.0 9.12. 2015
### Original Release

## V1.0.1 05.01.2015
### Bugfixing
    - fix for dropdowns inside off canvas menu
    - fix for notifications' alerts inside cols or cards

## V1.0.2 19.01.2016
### New Example Page Added
    - added twitter re-design example

## V1.0.3 27.01.2016
### Small changes in Presentation Page
    - fix for presentation page
## V1.0.4 18.02.2016
### Plugin Updates + Fixes [Current Version]
    - bootstrap select plugin update to 1.8.1
    - fix bootstrap select issue on Safari
    - fixed switches masks
    - fixed datepicker margins
## V1.0.5 31.05.2016
### BugFixing
    - fixed sidebar for twitter redesign example page

## V1.0.6 14.06.2016
### BugFixing

## V1.0.7 11.10.2016
### BugFixing
    - removed CSS maps and fixed folders version name

## 03.08.2017
### Updated license notice
